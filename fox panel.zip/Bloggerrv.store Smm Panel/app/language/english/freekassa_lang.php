<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 *
 * Free-Kassa
 *
 */
$lang["freekassa_confirm_form"] = "Free-Kassa Confirm Form";
$lang["choose_payment_method"] = "Choose a payment Method";
