<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 *
 * Paywant
 *
 */
$lang["Paywant_Integration"]    = "Paywant Integration";
$lang["Paywant_Integration"]    = "Paywant Integration";
