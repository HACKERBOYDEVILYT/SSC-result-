<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 *
 * PerfectMoney
 *
 */
$lang["perfect_money"] = "Perfect Money";
$lang["perfect_money_integration"] = "Perfect Money integration";
$lang["perfect_money_account_id_usd"] = "Perfect Money Account ID (USD)";
$lang["perfect_money_confirmation"] = "Perfect Money® Confirmation";
$lang["total_amount_usd_includes_fee"] = "Total Amount (USD) (Includes fee):";
